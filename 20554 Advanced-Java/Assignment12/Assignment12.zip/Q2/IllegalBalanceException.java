public class IllegalBalanceException extends Exception {

    public IllegalBalanceException() {
        super();
    }

    public IllegalBalanceException(String cause) {
        super(cause);
    }

}
